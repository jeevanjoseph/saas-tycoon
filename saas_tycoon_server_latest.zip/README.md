# SaaS Tycoon Server

This Node.js server supports the SaaS Tycoon game backend.
