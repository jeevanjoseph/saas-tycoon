const { v4: uuidv4 } = require('uuid');
const createPlayer = require('./player');

function createGameSession(playerLimit = 5) {
  return {
    id: uuidv4(),
    players: [],
    playerLimit,
    currentTurn: 1,
    started: false,
    events: [],
    log: [],
    createdAt: new Date().toISOString()
  };
}

function canStartGame(session) {
  const readyCount = session.players.filter(p => p.ready).length;
  return readyCount >= 2 && readyCount === session.players.length;
}

module.exports = { createGameSession, canStartGame };